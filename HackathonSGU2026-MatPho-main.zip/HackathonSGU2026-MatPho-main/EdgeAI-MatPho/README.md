# TRI THỨC TOÀN DIỆN KHỐI EDGE AI (`EdgeAI-MatPho`)
## SINGLE SOURCE OF TRUTH CHO CLOUD BACKEND, FRONTEND APP & TEAM AI

> **Vị trí tài liệu**: `docs/EDGE_AI_KNOWLEDGE_BASE.md` (Bản sao tại `EdgeAI-MatPho/README.md`)  
> **Mục đích**: Đây là **Bản Tri Thức Chuẩn Hóa Duy Nhất (Single Source of Truth)** của toàn bộ khối `EdgeAI-MatPho`.  
> Bất kỳ Agent hoặc Developer nào làm việc ở **Cloud Backend (`backend/`)**, **Flutter App (`frontend/`)**, hoặc **FireWatch (`FireWatchAI/`)** chỉ cần đọc file này là nắm được **100% kiến trúc, luồng video, cổng mạng, schema SQLite, hợp đồng API/WebSocket và chỗ gắn model AI** mà **KHÔNG CẦN đọc lại từng file code bên trong `EdgeAI-MatPho`**.

---

## 1. TỔNG QUAN KIẾN TRÚC & VAI TRÒ KHỐI EDGE (`EdgeAI-MatPho`)

Khối `EdgeAI-MatPho` là cụm dịch vụ chạy tại hiện trường (trên Mini PC / Box AI nằm trong cùng mạng LAN với các Camera IP, hoặc chạy trên Docker local khi demo Hackathon), gồm **3 dịch vụ cốt lõi**:

1. **`mediamtx` (Edge Stream Gateway - Cổng `:8554`, `:8888`, `:8889`, `:9997`)**:
   - Nhận luồng video H.264 đã chuẩn hóa tại đường dẫn `live/{cam_id}`.
   - Tự động đóng gói sang **Low-Latency HLS (`http://<edge_host>:8888/live/{cam_id}/index.m3u8`)** để phát trực tiếp lên **Mobile/Web App**.
   - Cung cấp đầu ra **RTSP nội bộ (`rtsp://mediamtx:8554/live/{cam_id}`)** để **Khối AI (`firewatch-ai`)** đọc frame mà không cần kết nối lại vào camera thật.
2. **`edge-backend` (Autonomous Edge Controller & PyAV Stream Worker - Cổng `:8090`)**:
   - **Động cơ Video PyAV (`DecodeManager`)**: Đọc luồng RTSP gốc từ Camera IP trong LAN (hoặc nguồn giả lập `mock/cam_test`), tự động **Zero-Copy Remux** (nếu camera là H.264) hoặc **Transcode sang H.264** (nếu camera là H.265/HEVC) và đẩy vào `rtsp://mediamtx:8554/live/{cam_id}`.
   - **LAN Camera Probe (`probe.py`)**: Thăm dò trực tiếp Camera IP trong mạng LAN (Port 554), trích xuất độ phân giải, FPS, nhận diện hãng camera (Hikvision, Dahua, Imou, Ezviz...) và chụp 1 ảnh tĩnh JPEG Base64.
   - **Cơ sở dữ liệu Nội bộ (`SQLite WAL - edge_local.db`)**: Lưu danh sách camera (`local_cameras`) để tự khởi chạy khi mất mạng Internet, và hàng đợi sự kiện cháy (`offline_events_queue`) để tự động đồng bộ bù (Store-and-Forward) khi có mạng lại.
   - **Kênh WebSocket Chủ động (`ws_client.py`)**: Kết nối chiều đi (Outbound) lên Cloud Backend (`/api/v1/internal/edge/ws`) giúp điều khiển Edge xuyên tường lửa/NAT mà không cần mở port router (Zero Inbound Ports).
3. **`firewatch-ai` (FireWatchAI, build từ `./FireWatchAI`)**:
   - Đọc `rtsp://mediamtx:8554/live/{cam_id}` của mọi camera mà edge-backend đang quét (lịch quét đồng bộ mỗi 2 s qua `GET /api/v1/edge/cameras`), phát hiện lửa/khói bằng FireWatch-v2.0 (YOLO26n ONNX, CPU), voting 6/10, xác minh Gemini, gom mỗi đám cháy thành một `event_id`.
   - Gửi event qua cổng chuyển tiếp `POST /api/v1/edge/ai-events` của edge-backend; trọng số đặt ở `FireWatchAI/models/` (kiểm SHA-256 lúc khởi động). Chi tiết: `FireWatchAI/docs/van_hanh.md` mục 11, hợp đồng event: `FireWatchAI/docs/ban_giao_backend.md`.

---

## 2. SƠ ĐỒ LUỒNG ĐI CỦA VIDEO & DỮ LIỆU (END-TO-END FLOW)

```mermaid
flowchart LR
    subgraph LAN ["Mạng LAN Hiện Trường / Docker Edge"]
        CAM["Camera IP Thực Tế\nhoặc scripts/mock_camera.py\n(rtsp://.../mock/cam_test)"]
        EB["edge-backend (:8090)\nPyAV Stream Worker\n+ SQLite WAL + LAN Probe"]
        MTX["MediaMTX Gateway\nPath chuẩn: live/{cam_id}"]
        AI["firewatch-ai (FireWatchAI)\nYOLO26n + voting + VLM"]
    end

    subgraph CLOUD ["Cloud Backend & App"]
        BE["Cloud Backend FastAPI (:8000)\n/api/v1/internal/edge/ws\n/api/v1/internal/ai/fire-events"]
        APP["Mobile / Web App (Flutter)\nXem HLS Trực Tiếp"]
    end

    CAM -->|"1. RTSP Gốc (H.264/H.265)"| EB
    EB -->|"2. Publish H.264 chuẩn\nrtsp://mediamtx:8554/live/{cam_id}"| MTX
    MTX -->|"3a. Nhánh HLS lên App (:8888)\n/live/{cam_id}/index.m3u8"| APP
    MTX -->|"3b. Đường Input RTSP (:8554)\nrtsp://mediamtx:8554/live/{cam_id}"| AI
    AI -->|"4. Đường Output Webhook\nPOST /api/v1/internal/ai/fire-events"| BE
    EB <-->|"5. Outbound WebSocket\nSYNC_CAMERA / PROBE / HEARTBEAT"| BE
```

### 🛡️ Chốt chặn chống lỗi "Tự đọc chính mình" (Anti Self-Loopback)
- Trong `edge_backend/src/config.py` và `edge_backend/src/main.py`:
  - `source_path_template = "source/{cam_id}"`
  - `app_path_template = "live/{cam_id}"` (Đầu ra chính cho cả HLS App & RTSP AI)
  - `ai_path_template = "ai/{cam_id}"` (Chỉ dùng khi bật `ENABLE_AI_BRANCH=true`)
- Nếu một lệnh `SYNC_CAMERA` truyền nhầm `rtsp_url` trùng với đường dẫn đích `rtsp://mediamtx:8554/live/{cam_id}` hoặc chứa từ khóa `mock-camera` / `test-valid`, hàm `resolve_safe_source_url()` sẽ tự động chuyển hướng nguồn đọc về `rtsp://mediamtx:8554/mock/cam_test` để không bao giờ gây lỗi đụng độ Publisher trên MediaMTX.

---

## 3. BẢN ĐỒ CẤU TRÚC THƯ MỤC & CHỨC NĂNG TỪNG FILE

```text
EdgeAI-MatPho/
├── docker-compose.yml              # Khởi chạy toàn bộ 3 container: mediamtx, edge-backend, firewatch-ai
├── .env.example                    # Danh mục đầy đủ biến môi trường mẫu
├── README.md                       # Bản sao tri thức toàn diện của khối EdgeAI
├── mediamtx/
│   └── mediamtx.yml                # Cấu hình RTSP (:8554), Low-Latency HLS (:8888), WebRTC (:8889), API (:9997)
├── scripts/
│   └── mock_camera.py              # Script PyAV tạo luồng video H.264 giả lập đẩy vào rtsp://localhost:8554/mock/cam_test
├── edge_backend/                   # [DỊCH VỤ 2] Bộ điều khiển Edge & Động cơ xử lý luồng PyAV (Port 8090)
│   ├── Dockerfile
│   ├── requirements.txt
│   ├── pytest.ini
│   ├── src/
│   │   ├── main.py                 # FastAPI Gateway nội bộ (:8090), Lifespan, REST APIs & xử lý lệnh Cloud WS
│   │   ├── config.py               # DecoderSettings, StreamSpec, ẩn mật khẩu RTSP (redact_url) & chống Loopback
│   │   ├── db.py                   # SQLite WAL Manager: bảng local_cameras & offline_events_queue
│   │   ├── probe.py                # CameraProbeService: thăm dò RTSP LAN, đo FPS/Resolution, chụp ảnh Base64
│   │   ├── ws_client.py            # OutboundCloudWSClient: giữ kết nối WS lên Cloud & xả hàng đợi Offline
│   │   ├── manager.py              # DecodeManager: quản lý vòng đời đa luồng các phiên DecodeSession
│   │   ├── session.py              # DecodeSession: giám sát từng camera, tự động kết nối lại với ExponentialBackoff
│   │   ├── pipeline.py             # Vòng lặp demux/decode PyAV, chờ I-Frame (Keyframe), chia nhánh Live/AI
│   │   ├── branches.py             # CopyLiveBranch (H.264 zero-copy), TranscodeLiveBranch (H.265->H.264), AiBranch
│   │   ├── sinks.py                # CopySink & H264Sink: đóng gói muxer RTSP/MKV với chuẩn 90kHz clock
│   │   ├── endpoints.py            # Mở kết nối PyAV RTSP với timeout cấp C-socket (open_timeout_s, read_timeout_s)
│   │   ├── sampler.py              # FrameRateSampler: lấy mẫu khung hình theo đồng hồ PTS của nguồn
│   │   ├── scaling.py              # fit_even: tính kích thước thu phóng chẵn pixel cho bộ mã hóa H.264
│   │   ├── backoff.py              # ExponentialBackoff có jitter ngẫu nhiên chống bão kết nối
│   │   └── stats.py                # SessionStats & SessionState: theo dõi số gói tin, số frame, trạng thái luồng
│   └── tests/                      # 156 Unit & Media Integration Tests (100% PASS)
└── FireWatchAI/                    # [DỊCH VỤ 3] FireWatch: phát hiện lửa/khói, voting, xác minh VLM, gom sự cố
    ├── Dockerfile                  # Lệnh mặc định "edge": mọi camera của nút biên trong một container
    ├── config.yaml                 # Ngưỡng, voting 6/10, VLM, gom sự cố (một file cấu hình duy nhất)
    ├── models/README.md            # Cách lấy trọng số FireWatch-v2.0 (.pt + .onnx) và SHA-256
    ├── src/firewatch/              # pipeline, detector, voting, vlm, su_co, nut_bien (chế độ edge)
    ├── docs/                       # van_hanh.md, ban_giao_backend.md, kien_truc.md, mau_event.json
    └── tests/                      # pytest (chạy bằng .venv của FireWatchAI)
```

---

## 4. HỢP ĐỒNG GIAO TIẾP VỚI CÁC KHỐI KHÁC (INTEGRATION CONTRACTS)

### A. Hợp đồng với **Mobile / Web App (`frontend/`)**
1. **Đường dẫn xem trực tiếp Camera (HLS Playback URL)**:
   - Định dạng chuẩn:
     ```text
     http://<EDGE_HOST>:8888/live/{cam_id}/index.m3u8
     ```
   - Ví dụ local/LAN: `http://localhost:8888/live/cam_01/index.m3u8` (hoặc qua domain tunnel `https://stream.matpho.vn/live/cam_01/index.m3u8`).
2. **Định dạng vùng quét `watch_area` (Tương thích kép 100%)**:
   - App ở màn hình **I5 / I8** gửi tọa độ vùng khoanh chuẩn hóa `[0.0, 1.0]`. Khối Edge hỗ trợ tự động **CẢ 2 ĐỊNH DẠNG**:
     - **Định dạng 1 — Hình chữ nhật (Rectangle Dict - Chuẩn của App & Cloud Backend)**:
       ```json
       {
         "left": 0.1,
         "top": 0.2,
         "width": 0.5,
         "height": 0.4
       }
       ```
     - **Định dạng 2 — Đa giác (Polygon List - Chuẩn mở rộng)**:
       ```json
       [
         [0.1, 0.2],
         [0.6, 0.2],
         [0.6, 0.6],
         [0.1, 0.6]
       ]
       ```

---

### B. Hợp đồng với **Cloud Backend (`backend/`)**

#### 1. Kênh Outbound WebSocket (`Edge` $\to$ `Cloud Backend`)
- **Endpoint trên Cloud Backend**: `ws://<CLOUD_HOST>/api/v1/internal/edge/ws?edge_id={EDGE_DEVICE_ID}&secret={INTERNAL_API_SECRET_KEY}`
- **Headers xác thực**: `x-internal-secret: <INTERNAL_API_SECRET_KEY>`, `x-edge-id: <EDGE_DEVICE_ID>`
- **Các bản tin Cloud Backend gửi xuống Edge (`Server -> Edge`)**:
  - **Đồng bộ / Thêm / Sửa Camera (`SYNC_CAMERA`)**:
    ```json
    {
      "action": "SYNC_CAMERA",
      "cam_id": "cam_01",
      "cam_name": "Camera Cổng Chính",
      "rtsp_url": "rtsp://admin:123456@192.168.1.50:554/Streaming/Channels/101",
      "watch_area": {"left": 0.1, "top": 0.2, "width": 0.5, "height": 0.4},
      "is_active": true
    }
    ```
  - **Xóa Camera (`REMOVE_CAMERA`)**:
    ```json
    {
      "action": "REMOVE_CAMERA",
      "cam_id": "cam_01"
    }
    ```
  - **Thăm dò Camera trong LAN (`PROBE_CAMERA`)**:
    ```json
    {
      "action": "PROBE_CAMERA",
      "request_id": "req_123",
      "rtsp_url": "rtsp://admin:123456@192.168.1.50:554/Streaming/Channels/101"
    }
    ```
- **Các bản tin Edge phản hồi lên Cloud Backend (`Edge -> Server`)**:
  - `CAMERA_STATUS`:
    ```json
    {
      "type": "CAMERA_STATUS",
      "cam_id": "cam_01",
      "status": "ONLINE",
      "hls_stream_url": "http://localhost:8888/live/cam_01/index.m3u8",
      "rtsp_output_url": "rtsp://mediamtx:8554/live/cam_01"
    }
    ```
  - `EDGE_HEARTBEAT` (định kỳ mỗi 10s):
    ```json
    {
      "type": "EDGE_HEARTBEAT",
      "edge_device_id": "edg_local_01",
      "active_streams": 2,
      "timestamp": 1730000000.0
    }
    ```
  - `PROBE_RESULT`: Trả về kết quả thăm dò camera LAN kèm ảnh `preview_snapshot_base64`.

#### 2. Các REST API Nội bộ của `edge-backend` (Cổng `:8090`)
Khi Cloud Backend và `edge-backend` chạy chung mạng local/Docker, Cloud Backend cũng có thể gọi trực tiếp HTTP sang `http://localhost:8090`:
- `GET /health` hoặc `GET /api/v1/edge/health`: Kiểm tra trạng thái sống và số luồng đang chạy.
- `GET /api/v1/status`: Xem thống kê chi tiết từng phiên giải mã PyAV (`packets_in`, `frames_decoded`, `live_packets_out`, `restarts`, `state`).
- `POST /api/v1/edge/probe`: Thăm dò RTSP camera trong LAN (`{"rtsp_url": "rtsp://..."}`).
- `GET /api/v1/edge/cameras`: Lấy danh sách camera trong SQLite kèm `hls_stream_url` và `rtsp_output_url`.
- `POST /api/v1/edge/cameras`: Thêm/cập nhật camera và khởi chạy luồng RTSP $\to$ HLS ngay lập tức.
- `DELETE /api/v1/edge/cameras/{cam_id}`: Dừng luồng và xóa camera khỏi SQLite.
- `POST /api/v1/auth/stream-ticket`: Hook xác thực vé xem luồng cho MediaMTX.
- `POST /api/v1/edge/offline-events`: Lưu sự kiện báo cháy vào hàng đợi SQLite khi đứt cáp WAN.

#### 3. Các HTTP Webhooks từ `firewatch-ai` gửi lên Cloud Backend
Tất cả request đều đính kèm Header: `X-Internal-Secret: <INTERNAL_API_SECRET_KEY>`.
1. **Báo cháy chính thức (`POST /api/v1/internal/ai/fire-events`)**:
   ```json
   {
     "cam_id": "cam_01",
     "class_name": "fire",
     "confidence": 0.92,
     "timestamp": 1730000000.123,
     "bbox": [120.0, 80.0, 340.0, 290.0],
     "image_base64": "/9j/4AAQSkZJRgABAQAAAQABAAD..."
   }
   ```
2. **Đang xác minh nghi vấn - Viền vàng E2 (`POST /api/v1/internal/ai/verifying`)**:
   ```json
   {
     "cam_id": "cam_01",
     "sign": "fire",
     "confidence": 0.65,
     "message": "Đang xác minh tín hiệu nghi vấn...",
     "steps": [{"kind": "DETECTED", "name": "Phát hiện dấu hiệu nghi vấn", "at": 1730000000.0}]
   }
   ```
3. **Báo giả / Hạ cờ báo động - Toast E4 (`POST /api/v1/internal/ai/suppressed`)**:
   ```json
   {
     "cam_id": "cam_01",
     "alert_id": null,
     "summary": "Không phải cháy",
     "detail": "AI kết luận: Ánh đèn phản chiếu hoặc vật thể bình thường."
   }
   ```

---

### C. Hợp đồng với **FireWatch (`EdgeAI-MatPho/FireWatchAI/`)**

- **Đầu vào:** `rtsp://mediamtx:8554/live/{cam_id}` cho mỗi camera trong `GET /api/v1/edge/cameras` có `should_ai_scan_now = true` (cộng các camera khai trong `AI_CAMERA_STREAMS`, mặc định trống).
- **Đầu ra:** `POST /api/v1/edge/ai-events` (header bí mật nội bộ); edge-backend đổi `camera_id` -> `cam_id`, chuyển tín hiệu lên backend và tải ảnh pha 2 một lần mỗi `event_id`.
- **Điều kiện để app hú:** `cam_id` phải là camera đã tạo trong app (backend đồng bộ xuống edge qua `CLOUD_BACKEND_WS_URL`). Camera chỉ khai ở edge bị backend trả 404 `CAMERA_NOT_FOUND`; edge ghi log `Backend rejected fire event`.
- **Trọng số và cấu hình:** `FireWatchAI/models/README.md`, `FireWatchAI/config.yaml`; các biến `AI_TARGET_FPS`, `AI_CONFIDENCE_THRESHOLD`, `AI_ALERT_COOLDOWN_S`, `AI_MODEL_WEIGHTS_PATH` bị FireWatch bỏ qua.

---

## 5. THIẾT KẾ CƠ SỞ DỮ LIỆU NỘI BỘ SQLITE WAL (`edge_local.db`)

File DB nằm tại `EdgeAI-MatPho/edge_backend/data/edge_local.db` (hoặc `/app/data/edge_local.db` trong Docker), bật chế độ `PRAGMA journal_mode=WAL;` gồm 2 bảng:

1. **Bảng `local_cameras`**:
   | Cột | Kiểu | Mô tả |
   | :--- | :--- | :--- |
   | `cam_id` | `TEXT PRIMARY KEY` | Mã định danh camera (`cam_01`, ...) |
   | `cam_name` | `TEXT NOT NULL` | Tên hiển thị của camera |
   | `rtsp_url` | `TEXT NOT NULL` | Đường dẫn RTSP gốc trong mạng LAN |
   | `watch_area_json` | `TEXT` | Chuỗi JSON lưu Rectangle Dict hoặc Polygon List |
   | `is_active` | `INTEGER NOT NULL` | `1` (Đang chạy stream) hoặc `0` (Tạm dừng) |
   | `updated_at` | `REAL NOT NULL` | Epoch timestamp lần cập nhật cuối |

2. **Bảng `offline_events_queue` (Store-and-Forward khi mất mạng WAN)**:
   | Cột | Kiểu | Mô tả |
   | :--- | :--- | :--- |
   | `id` | `INTEGER PRIMARY KEY AUTOINCREMENT` | Khóa chính tự tăng (FIFO) |
   | `cam_id` | `TEXT NOT NULL` | Mã camera phát hiện cháy |
   | `event_type` | `TEXT NOT NULL` | Loại sự kiện (`FIRE_DETECTED`) |
   | `payload_json` | `TEXT NOT NULL` | Toàn bộ JSON payload báo cháy kèm ảnh Base64 |
   | `created_at` | `REAL NOT NULL` | Thời điểm phát hiện cháy tại hiện trường |
   | `retry_count` | `INTEGER NOT NULL` | Số lần thử gửi lại |

---

## 6. BẢNG CỔNG MẠNG (PORTS) & LỆNH KHỞI CHẠY NHANH

| Dịch vụ | Cổng (Port) | Giao thức | Mục đích sử dụng |
| :--- | :---: | :---: | :--- |
| **`mediamtx`** | `8554` | RTSP (TCP/UDP) | Nhận luồng publish từ `edge-backend` & cung cấp RTSP input cho `firewatch-ai` |
| **`mediamtx`** | `8888` | HTTP (HLS) | Phát video trực tiếp lên App: `http://localhost:8888/live/{cam_id}/index.m3u8` |
| **`mediamtx`** | `8889` | HTTP (WebRTC) | Phát WebRTC WHEP độ trễ cực thấp |
| **`mediamtx`** | `9997` | HTTP REST | MediaMTX Control API nội bộ |
| **`edge-backend`** | `8090` | HTTP REST | Cổng điều khiển Edge Backend, LAN Probe, Quản lý Camera & Healthcheck |

### 🚀 Lệnh Khởi Chạy Nhanh Bằng Script Tự Động (Automation Scripts)

Khối Edge đã được trang bị sẵn 3 script điều khiển tự động (tự động tạo `.env` từ `.env.example`, kiểm tra Docker daemon, phát hiện xung đột port và cung cấp Menu tương tác):

1. **Trên Windows (PowerShell)**:
   ```powershell
   cd EdgeAI-MatPho
   .\run_edge.ps1            # Mở Menu tương tác điều khiển [0-8]
   .\run_edge.ps1 up         # Khởi chạy cụm Edge tiêu chuẩn (3 containers)
   .\run_edge.ps1 up-mock    # Khởi chạy KÈM Camera Giả Lập Mock Counter OSD
   .\run_edge.ps1 up-gateway # Khởi chạy KÈM Edge HTTPS Gateway (Cloudflare Outbound Tunnel)
   .\run_edge.ps1 logs       # Xem logs thời gian thực
   .\run_edge.ps1 status     # Kiểm tra trạng thái containers, healthcheck & Public Gateway URL
   .\run_edge.ps1 down       # Dừng toàn bộ cụm Edge
   .\run_edge.ps1 clean      # Dọn dẹp sạch containers & volumes SQLite
   ```
2. **Trên Windows (Batch / Click đúp File Explorer)**:
   - Click đúp trực tiếp vào file [`EdgeAI-MatPho/run_edge.bat`](../EdgeAI-MatPho/run_edge.bat) trong File Explorer hoặc chạy:
   ```cmd
   cd EdgeAI-MatPho
   run_edge.bat              # Menu tương tác
   run_edge.bat up           # Khởi chạy
   run_edge.bat up-mock      # Khởi chạy kèm camera giả lập
   run_edge.bat up-gateway   # Khởi chạy kèm Cloudflare Tunnel HTTPS Gateway
   run_edge.bat down         # Dừng cụm
   ```
3. **Trên Linux / macOS / WSL (POSIX Shell)**:
   ```bash
   cd EdgeAI-MatPho
   chmod +x run_edge.sh
   ./run_edge.sh             # Mở Menu tương tác
   ./run_edge.sh up          # Khởi chạy
   ./run_edge.sh up-mock     # Khởi chạy kèm camera giả lập
   ./run_edge.sh up-gateway  # Khởi chạy kèm Cloudflare Tunnel
   ./run_edge.sh logs        # Xem logs
   ./run_edge.sh down        # Dừng cụm
   ```

4. **Chạy thủ công bằng Docker Compose cơ bản**:
   ```bash
   cd EdgeAI-MatPho
   cp .env.example .env
   # Khởi chạy 3 container tiêu chuẩn
   docker compose up -d --build
   # Khởi chạy kèm container giả lập camera:
   docker compose --profile mock up -d --build
   # Khởi chạy kèm Edge HTTPS Gateway xuyên mạng:
   docker compose --profile gateway --profile mock up -d --build
   ```

5. **Chạy Bộ Kiểm Thử Tự Động**:
   ```powershell
   # Test Edge Backend, PyAV Worker, Gateway Discovery & On-Demand Controller (161 tests)
   Push-Location EdgeAI-MatPho/edge_backend; pytest -q; Pop-Location

   # Test FireWatch (dùng .venv của FireWatchAI, xem FireWatchAI/README.md)
   Push-Location EdgeAI-MatPho/FireWatchAI; .venv\Scripts\python -m pytest -q; Pop-Location
   ```

---

## 7. KIẾN TRÚC ON-DEMAND STREAMING & EDGE HTTPS GATEWAY (PRODUCT STANDARD)

Để đưa hệ thống ra vận hành thực tế tại hàng nghìn khu phố mà không làm nghẽn băng thông mạng nhà dân và không tốn chi phí thuê VPS Cloud đắt đỏ, khối Edge áp dụng kiến trúc chuẩn của các hãng camera thương mại (như Ezviz, Imou, Hik-Connect):

### 1. Cơ chế Ngủ Đông & Đánh Thức On-Demand (Băng Thông Chờ 0 MB/s)
- **99% thời gian**: Không có người xem trực tiếp trên App. Cục Edge chỉ đọc RTSP nội bộ trong mạng LAN (0 đồng tiền mạng Internet) để AI chạy ngầm. Nhánh Live Stream ra ngoài Internet hoàn toàn tắt (`IDLE`).
- **Khi có người bấm xem trên App**:
  1. Cloud Backend nhận request `GET /api/v1/cameras/{id}/stream` (đã xác thực JWT & phân quyền 4 vai trò).
  2. Cloud Backend gửi lệnh `{"type": "START_LIVE", "cam_id": "cam_01"}` qua kênh Outbound WebSocket xuống cục Edge.
  3. Edge Controller bật nhánh `live/{cam_id}` trên MediaMTX và đặt bộ đếm TTL 60 giây (`live_idle_ttl_s = 60.0`).
  4. App gửi nhịp `POST /cameras/{id}/stream/keepalive` mỗi 30s để gia hạn xem tiếp.
  5. Khi người dùng đóng App, gửi lệnh `POST /cameras/{id}/stream/stop` hoặc hết 60s không có người xem, Edge Controller tự động tắt nhánh Live về lại trạng thái ngủ đông.

### 2. Edge HTTPS Gateway (Xuyên Mọi Tường Lửa Không Cần Mở Port Router)
- **Container `edge-gateway` (`cloudflared`)**: Tự động mở đường hầm HTTPS bảo mật từ cục Edge ra mạng phân phối biên Cloudflare trên cổng `443`.
- **Module `gateway_discovery.py`**: Tự động nhận diện Public URL của chính nó (từ biến môi trường `EDGE_PUBLIC_HLS_URL` hoặc log file `/app/data/tunnel.log`).
- **Tự động đăng ký qua WebSocket**: Mỗi nhịp Heartbeat, Edge Node gửi kèm `public_hls_base_url` (ví dụ: `https://alpha-beta.trycloudflare.com` hoặc `https://edge-box-01.matpho.vn`) lên Cloud Backend `websocket_manager.py`.
- **Xem Video Xuyên Mạng**: App người dùng ở mạng 4G/Wifi trường thi tải trực tiếp các segment HLS qua đường link HTTPS an toàn mà không cần chạm vào cấu hình Modem/Router của nhà dân!

### 3. WebRTC P2P Chuẩn WHEP (Độ Trễ Dưới 0.5s)
- `mediamtx.yml` đã được kích hoạt cổng WebRTC `:8889` kèm cấu hình máy chủ STUN công cộng (`stun:stun.l.google.com:19302`, `stun:stun.cloudflare.com:3478`).
- Cho phép thiết lập luồng WebRTC P2P trực tiếp giữa điện thoại người xem và Cục Edge tại hiện trường khi cần xem video với độ trễ siêu thấp.
